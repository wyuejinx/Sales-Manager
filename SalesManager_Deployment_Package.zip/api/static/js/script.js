// Sidebar toggle removed; sidebar is a fixed layout now.

const themeToggle = document.getElementById('themeModeToggle');

if (themeToggle) {
    const savedTheme = localStorage.getItem('salesManagerTheme');
    if (savedTheme === 'light') {
        document.body.classList.remove('dark-theme');
        themeToggle.checked = false;
    } else {
        document.body.classList.add('dark-theme');
        themeToggle.checked = true;
    }

    themeToggle.addEventListener('change', () => {
        if (themeToggle.checked) {
            document.body.classList.add('dark-theme');
            localStorage.setItem('salesManagerTheme', 'dark');
        } else {
            document.body.classList.remove('dark-theme');
            localStorage.setItem('salesManagerTheme', 'light');
        }
    });
}
// Profile dropdown logic removed.

// Live date, time, and greeting updater for navbar
function updateDateTime() {
    const el = document.getElementById('liveDateTime');
    const greetingEl = document.getElementById('greetingText');
    const now = new Date();

    if (greetingEl) {
        const hour = now.getHours();
        if (hour < 12) {
            greetingEl.textContent = 'Good morning';
        } else if (hour < 18) {
            greetingEl.textContent = 'Good afternoon';
        } else {
            greetingEl.textContent = 'Good evening';
        }
    }

    if (!el) return;
    const optionsDate = { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' };
    const dateStr = now.toLocaleDateString(undefined, optionsDate);
    const timeStr = now.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const dateSpan = el.querySelector('.date');
    const timeSpan = el.querySelector('.time');
    if (dateSpan) dateSpan.textContent = dateStr;
    if (timeSpan) timeSpan.textContent = timeStr;
}

updateDateTime();
setInterval(updateDateTime, 1000);

// Promise-based PIN Modal Controller
function showPinModal(actionName) {
    return new Promise((resolve, reject) => {
        const modal = document.getElementById('pinModal');
        const pinInput = document.getElementById('pinInput');
        const cancelBtn = document.getElementById('pinCancelBtn');
        if (!modal || !pinInput) {
            resolve(null);
            return;
        }

        // Reset input
        pinInput.value = '';
        
        // Update header description
        const desc = modal.querySelector('.pin-modal-header p');
        if (desc) {
            desc.textContent = `Please enter your PIN to authorize this ${actionName} action.`;
        }

        // Show modal
        modal.classList.remove('d-none');
        // Force reflow
        modal.offsetHeight;
        modal.classList.add('show');

        // Cleanup function
        function closeModal() {
            modal.classList.remove('show');
            setTimeout(() => {
                modal.classList.add('d-none');
            }, 300);
            window.removeEventListener('keydown', handleKeyboard);
        }

        // Handle numeric key click
        const keys = modal.querySelectorAll('.pin-key[data-val]');
        keys.forEach(key => {
            key.onclick = () => {
                if (pinInput.value.length < 8) {
                    pinInput.value += key.getAttribute('data-val');
                }
            };
        });

        // Clear key
        const clearKey = modal.querySelector('.pin-clear');
        if (clearKey) {
            clearKey.onclick = () => {
                pinInput.value = pinInput.value.slice(0, -1);
            };
        }

        // Submit key
        const submitKey = modal.querySelector('.pin-submit-key');
        if (submitKey) {
            submitKey.onclick = () => {
                const pin = pinInput.value;
                closeModal();
                resolve(pin);
            };
        }

        // Cancel button
        cancelBtn.onclick = () => {
            closeModal();
            resolve(null);
        };

        // Handle physical keyboard typing
        function handleKeyboard(e) {
            if (e.key >= '0' && e.key <= '9') {
                if (pinInput.value.length < 8) {
                    pinInput.value += e.key;
                }
            } else if (e.key === 'Backspace') {
                pinInput.value = pinInput.value.slice(0, -1);
            } else if (e.key === 'Enter') {
                const pin = pinInput.value;
                closeModal();
                resolve(pin);
            } else if (e.key === 'Escape') {
                closeModal();
                resolve(null);
            }
        }
        window.addEventListener('keydown', handleKeyboard);
    });
}

// Promise-based Deletion Confirmation Modal Controller
function showConfirmModal(message) {
    return new Promise((resolve) => {
        const modal = document.getElementById('confirmModal');
        const confirmText = document.getElementById('confirmModalText');
        const cancelBtn = document.getElementById('confirmCancelBtn');
        const okBtn = document.getElementById('confirmOkBtn');
        if (!modal || !confirmText || !cancelBtn || !okBtn) {
            resolve(false);
            return;
        }

        // Set message text
        confirmText.textContent = message || 'Are you sure you want to delete this record?';

        // Show modal
        modal.classList.remove('d-none');
        // Force reflow
        modal.offsetHeight;
        modal.classList.add('show');

        // Cleanup
        function closeModal() {
            modal.classList.remove('show');
            setTimeout(() => {
                modal.classList.add('d-none');
            }, 300);
            window.removeEventListener('keydown', handleKeyboard);
        }

        // Cancel clicks
        cancelBtn.onclick = () => {
            closeModal();
            resolve(false);
        };

        // Confirm clicks
        okBtn.onclick = () => {
            closeModal();
            resolve(true);
        };

        // Keyboard handler
        function handleKeyboard(e) {
            if (e.key === 'Enter') {
                closeModal();
                resolve(true);
            } else if (e.key === 'Escape') {
                closeModal();
                resolve(false);
            }
        }
        window.addEventListener('keydown', handleKeyboard);
    });
}

// Promise-based Alert Modal Controller (Access Denied / Errors)
function showAlertModal(title, message) {
    return new Promise((resolve) => {
        const modal = document.getElementById('alertModal');
        const alertTitle = document.getElementById('alertModalTitle');
        const alertText = document.getElementById('alertModalText');
        const okBtn = document.getElementById('alertOkBtn');
        if (!modal || !alertTitle || !alertText || !okBtn) {
            resolve();
            return;
        }

        // Set content text
        alertTitle.textContent = title || 'Access Denied';
        alertText.textContent = message || 'Incorrect Security PIN. Access Denied.';

        // Show modal
        modal.classList.remove('d-none');
        // Force reflow
        modal.offsetHeight;
        modal.classList.add('show');

        // Cleanup
        function closeModal() {
            modal.classList.remove('show');
            setTimeout(() => {
                modal.classList.add('d-none');
            }, 300);
            window.removeEventListener('keydown', handleKeyboard);
        }

        // Dismiss clicks
        okBtn.onclick = () => {
            closeModal();
            resolve();
        };

        // Keyboard handler
        function handleKeyboard(e) {
            if (e.key === 'Enter' || e.key === 'Escape') {
                closeModal();
                resolve();
            }
        }
        window.addEventListener('keydown', handleKeyboard);
    });
}

// Global Security PIN verification for Edit and Delete action buttons
document.addEventListener('DOMContentLoaded', () => {
    // Dynamic greeting based on current local time
    const greetingTextEl = document.getElementById('greetingText');
    if (greetingTextEl) {
        const hour = new Date().getHours();
        let greeting = "Welcome";
        if (hour >= 5 && hour < 12) {
            greeting = "Good morning";
        } else if (hour >= 12 && hour < 18) {
            greeting = "Good afternoon";
        } else {
            greeting = "Good evening";
        }
        greetingTextEl.textContent = greeting;
    }

    document.body.addEventListener('click', async (e) => {
        const actionLink = e.target.closest('.action-link.edit, .action-link.delete');
        if (!actionLink) return;

        // Stop default execution immediately
        e.preventDefault();
        e.stopPropagation();

        const actionUrl = actionLink.getAttribute('href');
        const isDelete = actionLink.classList.contains('delete');
        const actionName = isDelete ? 'Delete' : 'Edit';

        const enteredPin = await showPinModal(actionName);
        if (enteredPin === null) {
            return; // Cancelled
        }

        try {
            const response = await fetch('/verify_pin', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ pin: enteredPin })
            });
            const data = await response.json();

            if (data.success) {
                if (isDelete) {
                    let confirmText = 'Are you sure you want to delete this record?';
                    const confirmMsg = actionLink.getAttribute('onclick');
                    if (confirmMsg) {
                        const match = confirmMsg.match(/confirm\('([^']+)'\)/);
                        if (match && match[1]) {
                            confirmText = match[1];
                        }
                    }
                    
                    const confirmed = await showConfirmModal(confirmText);
                    if (!confirmed) {
                        return; // Cancelled
                    }
                }
                window.location.href = actionUrl;
            } else {
                await showAlertModal('Access Denied', data.message || 'Incorrect Security PIN. Access Denied.');
            }
        } catch (err) {
            console.error(err);
            await showAlertModal('Error', 'An error occurred during security verification. Please try again.');
        }
    }, true); // Intercept during capture phase to bypass native confirm alerts

    // Auto-fill price from selected service
    document.body.addEventListener('change', (e) => {
        if (e.target.name === 'service_id') {
            const selectEl = e.target;
            const selectedOption = selectEl.options[selectEl.selectedIndex];
            if (selectedOption) {
                const price = selectedOption.getAttribute('data-price');
                if (price !== null && price !== undefined) {
                    const form = selectEl.closest('form');
                    if (form) {
                        const amountInput = form.querySelector('input[name="amount"]');
                        if (amountInput) {
                            amountInput.value = price;
                        }
                    }
                }
            }
        }
    });
});
